<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Novo Registro</title>

</head>
<body background="https://st3.depositphotos.com/1781556/14737/i/1600/depositphotos_147379051-stock-photo-data-entry-concept.jpg">


    <h1> Novo Registro</h1>

    <form action=salvar.php >
	
    <p>Nome</p>
    <input type=text name=nome>
	
    <p>Data De Nascimento</p>
    <input type=date name=idade>
	
	<p>Salario</p>
    <input type=number name=salario>
    <br><br>
	
    <input type=submit value=Salvar>
    </form>

    </p>
</body>
</html>
